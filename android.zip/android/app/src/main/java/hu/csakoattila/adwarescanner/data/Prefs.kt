package hu.csakoattila.adwarescanner.data

import android.content.Context
import androidx.core.content.edit

/** Egyszerű, app-privát beállítások (a telefonon maradnak, biztonsági mentésbe nem kerülnek). */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("adware_scanner", Context.MODE_PRIVATE)

    /** A szerver utolsó ETag-je – ha nem változott a lista, nem töltjük le újra. */
    var listEtag: String?
        get() = sp.getString("list_etag", null)
        set(v) = sp.edit { putString("list_etag", v) }

    /** Utolsó sikeres listafrissítés ideje (ms). */
    var lastSync: Long
        get() = sp.getLong("last_sync", 0)
        set(v) = sp.edit { putLong("last_sync", v) }

    /** Utolsó ellenőrzés ideje (ms). */
    var lastScan: Long
        get() = sp.getLong("last_scan", 0)
        set(v) = sp.edit { putLong("last_scan", v) }

    /** Utolsó teljes (napi) ellenőrzés ideje (ms). */
    var lastFullScan: Long
        get() = sp.getLong("last_full_scan", 0)
        set(v) = sp.edit { putLong("last_full_scan", v) }

    /** PackageManager.getChangedPackages() sorszáma; újraindításkor nullázódik. */
    var changeSequence: Int
        get() = sp.getInt("change_seq", 0)
        set(v) = sp.edit { putInt("change_seq", v) }

    var bootCount: Int
        get() = sp.getInt("boot_count", -1)
        set(v) = sp.edit { putInt("boot_count", v) }

    /** Az ügyfél által „nem kérek rá figyelmeztetést” jelölésű csomagok. */
    var ignored: Set<String>
        get() = sp.getStringSet("ignored", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("ignored", v.toSet()) }

    /** Amikről már küldtünk értesítést (hogy ne ismételjük minden futáskor). */
    var notified: Set<String>
        get() = sp.getStringSet("notified", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("notified", v.toSet()) }

    /** Már bejelentett csomagok (hogy a gomb jelezze). */
    var reported: Set<String>
        get() = sp.getStringSet("reported", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("reported", v.toSet()) }

    /** Szervizmenü: admin token és felhasználónév. */
    var adminToken: String?
        get() = sp.getString("admin_token", null)
        set(v) = sp.edit { putString("admin_token", v) }

    var adminUser: String?
        get() = sp.getString("admin_user", null)
        set(v) = sp.edit { putString("admin_user", v) }

    var notificationAsked: Boolean
        get() = sp.getBoolean("notif_asked", false)
        set(v) = sp.edit { putBoolean("notif_asked", v) }
}
