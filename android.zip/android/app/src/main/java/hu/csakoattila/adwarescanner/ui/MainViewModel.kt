package hu.csakoattila.adwarescanner.ui

import android.app.Application
import android.os.Build
import android.os.PowerManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import hu.csakoattila.adwarescanner.data.Api
import hu.csakoattila.adwarescanner.data.AppInventory
import hu.csakoattila.adwarescanner.data.Blacklist
import hu.csakoattila.adwarescanner.data.BlacklistRepository
import hu.csakoattila.adwarescanner.data.InstalledApp
import hu.csakoattila.adwarescanner.data.Prefs
import hu.csakoattila.adwarescanner.data.Scanner
import hu.csakoattila.adwarescanner.data.Threat
import hu.csakoattila.adwarescanner.work.Notifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val loading: Boolean = true,
    val syncing: Boolean = false,
    val list: Blacklist = Blacklist.EMPTY,
    val apps: List<InstalledApp> = emptyList(),
    val threats: List<Threat> = emptyList(),          // aktív találatok
    val ignoredThreats: List<Threat> = emptyList(),   // amiket az ügyfél elnémított
    val lastSync: Long = 0,
    val lastScan: Long = 0,
    val reported: Set<String> = emptySet(),
    val adminUser: String? = null,
    val batteryOk: Boolean = true,
    val busy: Boolean = false,
    val message: String? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val repo = BlacklistRepository.get(app)
    private val inventory = AppInventory(app)

    private val _state = MutableStateFlow(UiState(adminUser = prefs.adminUser))
    val state: StateFlow<UiState> = _state.asStateFlow()

    /** Az Activity ezt figyeli: ha nem null, elindítja a rendszer eltávolító ablakát. */
    private val _uninstallRequest = MutableStateFlow<String?>(null)
    val uninstallRequest: StateFlow<String?> = _uninstallRequest.asStateFlow()
    private val uninstallQueue = ArrayDeque<String>()
    var launchedFor: String? = null

    init {
        refresh()
        // induláskor, ha régebbi a lista egy napnál, frissítünk
        if (System.currentTimeMillis() - prefs.lastSync > 20 * 3600_000L) syncNow(quiet = true)
    }

    /** Helyi újraellenőrzés (nincs hálózat). */
    fun refresh() {
        viewModelScope.launch {
            val list = repo.current()
            val apps = withContext(Dispatchers.Default) { inventory.all() }
            val all = Scanner.findThreats(apps, list)
            val ignored = prefs.ignored
            val active = all.filter { it.app.packageName !in ignored }
            // amit a felületen már látott, arról a háttér ne küldjön külön értesítést
            prefs.notified = prefs.notified + active.map { it.app.packageName }
            prefs.lastScan = System.currentTimeMillis()
            val pm = getApplication<Application>().getSystemService(PowerManager::class.java)
            _state.update {
                it.copy(
                    loading = false,
                    list = list,
                    apps = apps,
                    threats = active,
                    ignoredThreats = all.filter { t -> t.app.packageName in ignored },
                    lastSync = prefs.lastSync,
                    lastScan = prefs.lastScan,
                    reported = prefs.reported,
                    batteryOk = pm.isIgnoringBatteryOptimizations(getApplication<Application>().packageName),
                )
            }
        }
    }

    /** Lista letöltése a szerverről, majd újraellenőrzés. */
    fun syncNow(quiet: Boolean = false) {
        if (_state.value.syncing) return
        viewModelScope.launch {
            _state.update { it.copy(syncing = true) }
            val msg = when (val r = repo.sync()) {
                is BlacklistRepository.SyncResult.Updated -> "Tiltólista frissítve (${r.list.entries.size} app)."
                BlacklistRepository.SyncResult.NotModified -> "A tiltólista naprakész."
                is BlacklistRepository.SyncResult.Failed -> r.message
            }
            _state.update { it.copy(syncing = false, message = if (quiet) it.message else msg) }
            refresh()
        }
    }

    fun ignore(pkg: String) {
        prefs.ignored = prefs.ignored + pkg
        Notifier.cancel(getApplication<Application>(), pkg)
        refresh()
    }

    fun unignore(pkg: String) {
        prefs.ignored = prefs.ignored - pkg
        refresh()
    }

    // ---- Eltávolítás ----

    fun uninstall(pkg: String) {
        if (_uninstallRequest.value == null) _uninstallRequest.value = pkg
        else if (pkg !in uninstallQueue) uninstallQueue.addLast(pkg)
    }

    fun uninstallAll() {
        _state.value.threats.forEach { uninstall(it.app.packageName) }
    }

    /** Az eltávolító ablak bezárult (sikerrel vagy mégsem). */
    fun onUninstallFinished() {
        _uninstallRequest.value?.let { Notifier.cancel(getApplication<Application>(), it) }
        _uninstallRequest.value = null
        launchedFor = null
        refresh()
        // a sorban következő, ha még telepítve van
        while (uninstallQueue.isNotEmpty()) {
            val next = uninstallQueue.removeFirst()
            if (inventory.find(next) != null) {
                _uninstallRequest.value = next
                break
            }
        }
    }

    // ---- Bejelentés (ügyfél) ----

    fun suggest(app: InstalledApp, note: String, uninstallAfter: Boolean) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val r = Api.suggest(app, note)
            if (r.ok) prefs.reported = prefs.reported + app.packageName
            _state.update { it.copy(busy = false, message = r.message, reported = prefs.reported) }
            if (uninstallAfter) uninstall(app.packageName)
        }
    }

    // ---- Szervizmenü (admin) ----

    fun adminLogin(user: String, pass: String, onOk: () -> Unit) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val label = "${Build.MANUFACTURER} ${Build.MODEL}"
            val r = Api.adminLogin(user.trim(), pass, label)
            val token = r.json?.optString("token").orEmpty()
            if (r.ok && token.isNotEmpty()) {
                prefs.adminToken = token
                prefs.adminUser = user.trim()
                _state.update { it.copy(busy = false, adminUser = user.trim(), message = "Szervizmód bekapcsolva.") }
                onOk()
            } else {
                _state.update { it.copy(busy = false, message = r.message) }
            }
        }
    }

    fun adminLogout() {
        prefs.adminToken = null
        prefs.adminUser = null
        _state.update { it.copy(adminUser = null, message = "Kiléptél a szervizmódból.") }
    }

    fun adminAdd(app: InstalledApp, name: String, risk: String, category: String, reason: String, onOk: () -> Unit) {
        val token = prefs.adminToken ?: return
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val r = Api.adminAdd(token, app.packageName, name, risk, category, reason)
            if (r.json?.optString("error")?.contains("Bejelentkezés") == true ||
                r.json?.optString("error")?.contains("Lejárt") == true
            ) {
                prefs.adminToken = null
                prefs.adminUser = null
                _state.update { it.copy(adminUser = null) }
            }
            _state.update { it.copy(busy = false, message = r.message) }
            if (r.ok) {
                onOk()
                syncNow(quiet = true) // azonnal behúzzuk a frissített listát
            }
        }
    }

    fun consumeMessage() = _state.update { it.copy(message = null) }
}
