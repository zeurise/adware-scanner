package hu.csakoattila.adwarescanner.data

import android.content.Context
import android.util.Log
import hu.csakoattila.adwarescanner.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * A tiltólista betöltése és frissítése.
 * Sorrend: letöltött másolat (filesDir) → az APK-ba épített assets/blacklist.json.
 */
class BlacklistRepository(context: Context) {
    private val app = context.applicationContext
    private val prefs = Prefs(app)
    private val cacheFile = File(app.filesDir, "blacklist.json")

    @Volatile
    private var cached: Blacklist? = null

    suspend fun current(): Blacklist = withContext(Dispatchers.IO) {
        cached ?: load().also { cached = it }
    }

    private fun load(): Blacklist {
        if (cacheFile.exists()) {
            try {
                return Blacklist.parse(cacheFile.readText())
            } catch (e: Exception) {
                Log.w(TAG, "Hibás letöltött lista, a beépítettet használom", e)
            }
        }
        val bundled = app.assets.open("blacklist.json").bufferedReader().use { it.readText() }
        return Blacklist.parse(bundled)
    }

    sealed class SyncResult {
        data class Updated(val list: Blacklist) : SyncResult()
        data object NotModified : SyncResult()
        data class Failed(val message: String) : SyncResult()
    }

    /** Letölti a friss listát a szerverről (ETag-gel, így változatlan listát nem tölt le újra). */
    suspend fun sync(): SyncResult = withContext(Dispatchers.IO) {
        val conn = (URL(BuildConfig.API_BASE + "list.php").openConnection() as HttpURLConnection)
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "AdwareScanner/" + BuildConfig.VERSION_NAME)
            // ETag-et csak akkor küldünk, ha a letöltött másolat tényleg megvan
            if (cacheFile.exists()) prefs.listEtag?.let { conn.setRequestProperty("If-None-Match", it) }

            when (conn.responseCode) {
                HttpURLConnection.HTTP_NOT_MODIFIED -> {
                    prefs.lastSync = System.currentTimeMillis()
                    SyncResult.NotModified
                }
                HttpURLConnection.HTTP_OK -> {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val list = Blacklist.parse(body) // ha hibás, kivételt dob, és nem írjuk felül a régit
                    val tmp = File(app.filesDir, "blacklist.json.tmp")
                    tmp.writeText(body)
                    tmp.renameTo(cacheFile)
                    prefs.listEtag = conn.getHeaderField("ETag")
                    prefs.lastSync = System.currentTimeMillis()
                    cached = list
                    SyncResult.Updated(list)
                }
                else -> SyncResult.Failed("Szerverhiba: HTTP ${conn.responseCode}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Listafrissítés sikertelen", e)
            SyncResult.Failed("Nincs kapcsolat a szerverrel")
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        private const val TAG = "BlacklistRepo"

        @Volatile
        private var instance: BlacklistRepository? = null

        fun get(context: Context): BlacklistRepository =
            instance ?: synchronized(this) {
                instance ?: BlacklistRepository(context).also { instance = it }
            }
    }
}
