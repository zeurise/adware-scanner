package hu.csakoattila.adwarescanner.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import hu.csakoattila.adwarescanner.data.BlacklistEntry
import hu.csakoattila.adwarescanner.data.InstalledApp

/** Ügyfél: gyanús app bejelentése. */
@Composable
fun SuggestDialog(
    app: InstalledApp,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSend: (note: String, uninstallAfter: Boolean) -> Unit,
) {
    var note by remember { mutableStateOf("") }
    var del by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Gyanús app bejelentése") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${app.label}\n${app.packageName}", fontSize = 14.sp)
                Text(
                    "A fejlesztő megkapja az alkalmazás nevét, csomagnevét és a telepítés forrását. Személyes adat nem kerül elküldésre.",
                    fontSize = 12.sp, color = Color.Gray,
                )
                OutlinedTextField(
                    value = note, onValueChange = { if (it.length <= 300) note = it },
                    label = { Text("Mit csinál? (nem kötelező)") },
                    placeholder = { Text("pl. reklámokat dob fel, magától települt") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = del, onCheckedChange = { del = it })
                    Text("Utána töröld is a telefonról")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSend(note.trim(), del) }, enabled = !busy) { Text("Bejelentés") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Mégse") } },
    )
}

/** Szervizmenü: bejelentkezés. */
@Composable
fun AdminLoginDialog(busy: Boolean, onDismiss: () -> Unit, onLogin: (String, String) -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Szervizmód") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Belépés a csakoattila.hu/adware admin fiókkal.", fontSize = 13.sp)
                OutlinedTextField(user, { user = it }, label = { Text("Felhasználónév") }, singleLine = true)
                OutlinedTextField(
                    pass, { pass = it }, label = { Text("Jelszó") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onLogin(user, pass) }, enabled = !busy && user.isNotBlank() && pass.isNotEmpty()) {
                Text(if (busy) "Belépés…" else "Belépés")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Mégse") } },
    )
}

/** Szervizmenü: app felvétele a közös tiltólistára. */
@Composable
fun AdminAddDialog(
    app: InstalledApp,
    categories: Map<String, String>,
    existing: BlacklistEntry?,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSave: (name: String, risk: String, category: String, reason: String) -> Unit,
) {
    var name by remember { mutableStateOf(existing?.name ?: app.label) }
    var risk by remember { mutableStateOf(existing?.risk ?: "high") }
    var cat by remember { mutableStateOf(existing?.category ?: "other") }
    var reason by remember { mutableStateOf(existing?.reason ?: "") }
    var catOpen by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing != null) "Tiltólista bejegyzés módosítása" else "Felvétel a tiltólistára") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(app.packageName, fontSize = 12.sp, color = Color.Gray)
                OutlinedTextField(name, { name = it }, label = { Text("Megjelenő név") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = risk == "high", onClick = { risk = "high" }, label = { Text("Magas") })
                    FilterChip(selected = risk == "medium", onClick = { risk = "medium" }, label = { Text("Közepes") })
                }
                Column {
                    OutlinedButton(onClick = { catOpen = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Kategória: " + (categories[cat] ?: cat))
                    }
                    DropdownMenu(expanded = catOpen, onDismissRequest = { catOpen = false }) {
                        categories.forEach { (k, v) ->
                            DropdownMenuItem(text = { Text(v) }, onClick = { cat = k; catOpen = false })
                        }
                    }
                }
                OutlinedTextField(
                    reason, { if (it.length <= 300) reason = it },
                    label = { Text("Indoklás (ezt látja az ügyfél)") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name.trim(), risk, cat, reason.trim()) }, enabled = !busy && reason.isNotBlank()) {
                Text(if (busy) "Mentés…" else "Mentés")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Mégse") } },
    )
}
