package hu.csakoattila.adwarescanner

import android.app.Application
import hu.csakoattila.adwarescanner.work.Notifier
import hu.csakoattila.adwarescanner.work.ScanWorker

class AdwareScannerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
        ScanWorker.schedule(this)
    }
}
