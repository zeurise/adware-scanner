package hu.csakoattila.adwarescanner.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

/** Egy telepített alkalmazás adatai. */
data class InstalledApp(
    val packageName: String,
    val label: String,
    val versionName: String,
    val installer: String?,      // a telepítő csomagneve (pl. com.android.vending)
    val firstInstall: Long,
    val lastUpdate: Long,
    val isSystem: Boolean,       // gyári rendszerapp (frissítve is annak számít)
) {
    val installerLabel: String get() = installerLabel(installer)
}

/** Ember által olvasható telepítési forrás. */
fun installerLabel(installer: String?): String = when (installer) {
    "com.android.vending" -> "Play Áruház"
    "com.sec.android.app.samsungapps" -> "Galaxy Store"
    "com.huawei.appmarket" -> "Huawei AppGallery"
    "com.xiaomi.market", "com.xiaomi.mipicks", "com.xiaomi.discover" -> "Xiaomi GetApps"
    "com.oppo.market", "com.heytap.market" -> "OPPO App Market"
    "com.amazon.venezia" -> "Amazon Appstore"
    "com.google.android.packageinstaller", "com.android.packageinstaller",
    "com.samsung.android.packageinstaller", "com.miui.packageinstaller" -> "APK-fájlból telepítve"
    null, "" -> "Ismeretlen forrás"
    else -> installer
}

/** A telefonon lévő alkalmazások lekérdezése. */
class AppInventory(context: Context) {
    private val pm: PackageManager = context.applicationContext.packageManager
    private val self = context.packageName

    fun all(): List<InstalledApp> {
        val pkgs: List<PackageInfo> = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(0)
        }
        return pkgs.asSequence()
            .filter { it.packageName != self }
            .mapNotNull { toApp(it) }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    /** Egy konkrét csomag adatai, vagy null, ha nincs telepítve. */
    fun find(packageName: String): InstalledApp? = try {
        val info = if (Build.VERSION.SDK_INT >= 33) {
            pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(packageName, 0)
        }
        toApp(info)
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    private fun toApp(info: PackageInfo): InstalledApp? {
        val ai: ApplicationInfo = info.applicationInfo ?: return null
        val isSystem = (ai.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
        return InstalledApp(
            packageName = info.packageName,
            label = runCatching { ai.loadLabel(pm).toString() }.getOrDefault(info.packageName),
            versionName = info.versionName ?: "",
            installer = installerOf(info.packageName),
            firstInstall = info.firstInstallTime,
            lastUpdate = info.lastUpdateTime,
            isSystem = isSystem,
        )
    }

    private fun installerOf(pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) {
            pm.getInstallSourceInfo(pkg).installingPackageName
        } else {
            @Suppress("DEPRECATION")
            pm.getInstallerPackageName(pkg)
        }
    } catch (e: Exception) {
        null
    }
}
