package hu.csakoattila.adwarescanner.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import hu.csakoattila.adwarescanner.BuildConfig

@Composable
fun AboutScreen(state: UiState, vm: MainViewModel, openUrl: (String) -> Unit, modifier: Modifier = Modifier) {
    var taps by remember { mutableIntStateOf(0) }
    var lastTap by remember { mutableLongStateOf(0L) }
    var showLogin by remember { mutableStateOf(false) }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Adware Scanner", style = MaterialTheme.typography.headlineSmall, color = Brand, fontWeight = FontWeight.Bold)
                Text(
                    "Verzió ${BuildConfig.VERSION_NAME}",
                    fontSize = 13.sp, color = Color.Gray,
                    // Rejtett szervizmenü: 7 gyors koppintás a verziószámra
                    modifier = Modifier.clickable {
                        val now = System.currentTimeMillis()
                        taps = if (now - lastTap < 1500) taps + 1 else 1
                        lastTap = now
                        if (taps >= 7) {
                            taps = 0
                            if (state.adminUser == null) showLogin = true
                        }
                    },
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Felismeri a reklámokkal teli, kéretlen alkalmazásokat egy nyilvános tiltólista alapján, " +
                        "és segít eltávolítani őket. Nem gyűjt személyes adatot, nincs benne reklám.",
                    fontSize = 14.sp,
                )
                TextButton(onClick = { openUrl(BuildConfig.PUBLIC_URL) }) { Text("Hogyan működik? Teljes tiltólista") }
                TextButton(onClick = { openUrl(BuildConfig.GITHUB_URL) }) { Text("Forráskód (GitHub)") }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Fejlesztő és üzemeltető", fontWeight = FontWeight.Bold, color = Brand)
                Text("Csákó Attila", fontWeight = FontWeight.SemiBold)
                TextButton(onClick = { openUrl("https://csakoattila.hu") }) { Text("csakoattila.hu") }
                TextButton(onClick = { openUrl("mailto:" + BuildConfig.CONTACT_EMAIL) }) { Text(BuildConfig.CONTACT_EMAIL) }
            }
        }

        if (state.adminUser != null) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Szervizmód aktív", fontWeight = FontWeight.Bold, color = Danger)
                    Text("Bejelentkezve: ${state.adminUser}. Az „Összes app” fülön bármelyik app felvehető a tiltólistára.", fontSize = 13.sp)
                    Text("Ügyfél telefonján a munka végén lépj ki!", fontSize = 13.sp, color = Danger)
                    TextButton(onClick = { vm.adminLogout() }) { Text("Kilépés a szervizmódból") }
                }
            }
        }

        Text(
            "Tiltólista: ${state.list.entries.size} app · verzió ${state.list.version}",
            fontSize = 12.sp, color = Color.Gray,
        )
    }

    if (showLogin) {
        AdminLoginDialog(
            busy = state.busy,
            onDismiss = { showLogin = false },
            onLogin = { u, p -> vm.adminLogin(u, p) { showLogin = false } },
        )
    }
}
