<?php
/**
 * Nyomtatható ügyféltájékoztató (A4 lapon két egyforma A5 példány, félbevágható).
 * https://telefonvilag.hu/adware/tajekoztato.php
 */
declare(strict_types=1);
require __DIR__ . '/inc/lib.php';

$public = (string)cfg('public_url');
$github = (string)cfg('github_url');
$short = preg_replace('#^https?://#', '', rtrim($public, '/'));
$ghShort = preg_replace('#^https?://#', '', $github);

$copy = function () use ($short, $ghShort): void { ?>
  <div class="sheet">
    <h1>Adware Scanner</h1>
    <div class="sub">Tájékoztató a telefonjára telepített védelmi alkalmazásról</div>

    <h2>Mire jó?</h2>
    <p>Felismeri a reklámokkal teli, kéretlen alkalmazásokat (kamu „frissítők”, „vírusirtók”, „tisztítók”, reklámos kamerák, PDF-olvasók, játékok), és segít eltávolítani őket.</p>

    <h2>Hogyan működik?</h2>
    <ul>
      <li>Ha új alkalmazás települ és az tiltólistás, <b>értesítést kap</b> egy „Törlés” gombbal.</li>
      <li>Az eltávolítást <b>mindig Önnek kell jóváhagynia</b> a telefon saját ablakában – magától semmit nem töröl.</li>
      <li>Ha valamit gyanúsnak talál, az alkalmazásban a „Gyanús, bejelentem” gombbal jelezheti nekünk.</li>
      <li>Ha egy tiltott alkalmazást mégis megtartana, a „Megtartom” gombbal elnémíthatja rá a figyelmeztetést.</li>
    </ul>

    <h2>Adatvédelem</h2>
    <p>Nem gyűjt személyes adatot, nincs benne reklám, nem kér fiókot. Az alkalmazáslista a telefonon marad. Csak az Ön által bejelentett alkalmazás neve kerül hozzánk.</p>

    <h2>Nyilvános információ, forráskód</h2>
    <p>Működés és teljes tiltólista: <b><?= h($short) ?></b><br>
       Forráskód: <b><?= h($ghShort) ?></b></p>

    <div class="fill">Telepítette: ______________________ &nbsp; Dátum: ______________</div>

    <div class="foot">
      <b>TELEFONVILÁG Kft.</b> · 4033 Debrecen, Jázmin utca 8. · +36 70 772 2607 · kapcsolat@telefonvilag.hu · telefonvilag.hu<br>
      Fejlesztő: Csákó Attila · csakoattila.hu
    </div>
  </div>
<?php };
?>
<!doctype html>
<html lang="hu">
<head>
<meta charset="utf-8">
<title>Adware Scanner – ügyféltájékoztató</title>
<style>
  @page { size: A4 portrait; margin: 0; }
  * { box-sizing: border-box; }
  body { margin: 0; font: 10.5pt/1.4 system-ui, Arial, sans-serif; color: #111; background: #ddd; }
  .page { width: 210mm; height: 297mm; margin: 10mm auto; background: #fff; display: flex; flex-direction: column; }
  .sheet { height: 148.5mm; padding: 9mm 13mm 7mm; position: relative; overflow: hidden; }
  .sheet + .sheet { border-top: 1px dashed #999; }
  h1 { margin: 0; font-size: 19pt; color: #0b6b3a; }
  .sub { color: #444; margin-bottom: 3mm; }
  h2 { font-size: 11pt; margin: 2.5mm 0 1mm; color: #0b6b3a; }
  p, ul { margin: 0 0 1mm; }
  ul { padding-left: 5mm; }
  .fill { margin-top: 3mm; }
  .foot { position: absolute; bottom: 6mm; left: 13mm; right: 13mm; font-size: 8.5pt; color: #333; border-top: 1px solid #ccc; padding-top: 1.5mm; }
  .noprint { text-align: center; padding: 10px; }
  @media print { body { background: #fff; } .page { margin: 0; } .noprint { display: none; } }
</style>
</head>
<body>
<div class="noprint"><button onclick="print()">Nyomtatás</button> – A4 lap, két példány, félbevágható</div>
<div class="page">
  <?php $copy(); $copy(); ?>
</div>
</body>
</html>
