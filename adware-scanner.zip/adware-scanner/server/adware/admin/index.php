<?php
/**
 * Adware Scanner – webes admin
 * /adware/admin/            javaslatok, tiltólista, mobil bejelentkezések
 * Első megnyitáskor (ha még nincs admin) létrehozza az első fiókot.
 */
declare(strict_types=1);
require __DIR__ . '/../inc/lib.php';

session_name('adwareadmin');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict', 'secure' => !empty($_SERVER['HTTPS'])]);
session_start();
header('X-Frame-Options: DENY');

$pdo = db();
$msg = '';
$err = '';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

function check_csrf(): void
{
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
        http_response_code(400);
        exit('Érvénytelen űrlap (CSRF). Töltsd újra az oldalt.');
    }
}

$noAdmins = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn() === 0;
$action = $_POST['action'] ?? '';

// ---- Első admin létrehozása ----
if ($noAdmins && $action === 'setup') {
    check_csrf();
    $u = clean_text($_POST['username'] ?? '', 60);
    $p = (string)($_POST['password'] ?? '');
    if ($u === '' || strlen($p) < 10) {
        $err = 'Felhasználónév kell, a jelszó legalább 10 karakter.';
    } else {
        $pdo->prepare('INSERT INTO admins (username, password_hash, created_at) VALUES (?,?,?)')
            ->execute([$u, password_hash($p, PASSWORD_DEFAULT), now()]);
        session_regenerate_id(true);
        $_SESSION['admin'] = $u;
        header('Location: ./');
        exit;
    }
}

// ---- Bejelentkezés / kijelentkezés ----
if ($action === 'login') {
    check_csrf();
    $ip = ip_hash();
    $st = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip_hash = ? AND created_at > ?');
    $st->execute([$ip, gmdate('Y-m-d H:i:s', time() - 900)]);
    if ((int)$st->fetchColumn() >= 10) {
        $err = 'Túl sok sikertelen próbálkozás, várj 15 percet.';
    } else {
        $st = $pdo->prepare('SELECT username, password_hash FROM admins WHERE username = ?');
        $st->execute([clean_text($_POST['username'] ?? '', 60)]);
        $a = $st->fetch();
        if ($a && password_verify((string)($_POST['password'] ?? ''), $a['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin'] = $a['username'];
            header('Location: ./');
            exit;
        }
        $pdo->prepare('INSERT INTO login_attempts (ip_hash, created_at) VALUES (?, ?)')->execute([$ip, now()]);
        $err = 'Hibás felhasználónév vagy jelszó.';
    }
}
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ./');
    exit;
}

$me = $_SESSION['admin'] ?? null;

// ---- Műveletek (csak bejelentkezve) ----
if ($me && $action !== '') {
    check_csrf();
    switch ($action) {
        case 'save_entry':
            $pkg = clean_text($_POST['package'] ?? '', 200);
            if (!valid_package($pkg)) {
                $err = 'Érvénytelen csomagnév: ' . $pkg;
                break;
            }
            $risk = isset(RISKS[$_POST['risk'] ?? '']) ? $_POST['risk'] : 'medium';
            $cat = isset(CATEGORIES[$_POST['category'] ?? '']) ? $_POST['category'] : 'other';
            upsert_entry($pkg, clean_text($_POST['name'] ?? '', 120), $risk, $cat, clean_text($_POST['reason'] ?? '', 300), $me);
            $msg = 'Mentve: ' . $pkg;
            break;
        case 'toggle_entry':
            $pdo->prepare('UPDATE blacklist SET active = 1 - active, updated_at = ?, updated_by = ? WHERE id = ?')
                ->execute([now(), $me, (int)$_POST['id']]);
            bump_list_version();
            $msg = 'Állapot módosítva.';
            break;
        case 'delete_entry':
            $pdo->prepare('DELETE FROM blacklist WHERE id = ?')->execute([(int)$_POST['id']]);
            bump_list_version();
            $msg = 'Törölve.';
            break;
        case 'reject':
            $pdo->prepare("UPDATE suggestions SET status = 'rejected' WHERE package = ? AND status = 'pending'")
                ->execute([clean_text($_POST['package'] ?? '', 200)]);
            $msg = 'Javaslat elutasítva.';
            break;
        case 'revoke_token':
            $pdo->prepare('DELETE FROM admin_tokens WHERE id = ?')->execute([(int)$_POST['id']]);
            $msg = 'Mobil bejelentkezés visszavonva.';
            break;
        case 'change_password':
            $p = (string)($_POST['password'] ?? '');
            if (strlen($p) < 10) {
                $err = 'A jelszó legalább 10 karakter legyen.';
            } else {
                $pdo->prepare('UPDATE admins SET password_hash = ? WHERE username = ?')->execute([password_hash($p, PASSWORD_DEFAULT), $me]);
                $msg = 'Jelszó módosítva.';
            }
            break;
        case 'add_admin':
            $u = clean_text($_POST['username'] ?? '', 60);
            $p = (string)($_POST['password'] ?? '');
            if ($u === '' || strlen($p) < 10) {
                $err = 'Felhasználónév kell, a jelszó legalább 10 karakter.';
            } else {
                try {
                    $pdo->prepare('INSERT INTO admins (username, password_hash, created_at) VALUES (?,?,?)')
                        ->execute([$u, password_hash($p, PASSWORD_DEFAULT), now()]);
                    $msg = 'Új admin: ' . $u;
                } catch (PDOException $e) {
                    $err = 'Ilyen felhasználó már létezik.';
                }
            }
            break;
    }
}

$tab = $_GET['tab'] ?? 'suggestions';

function risk_select(string $sel = 'high'): string
{
    $o = '';
    foreach (RISKS as $k => $v) {
        $o .= '<option value="' . $k . '"' . ($k === $sel ? ' selected' : '') . '>' . h($v) . '</option>';
    }
    return '<select name="risk">' . $o . '</select>';
}

function cat_select(string $sel = 'other'): string
{
    $o = '';
    foreach (CATEGORIES as $k => $v) {
        $o .= '<option value="' . $k . '"' . ($k === $sel ? ' selected' : '') . '>' . h($v) . '</option>';
    }
    return '<select name="category">' . $o . '</select>';
}
?>
<!doctype html>
<html lang="hu">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Adware Scanner – admin</title>
<style>
  :root { --c:#0b6b3a; --red:#b3261e; --bg:#f5f6f7; }
  * { box-sizing: border-box; }
  body { font: 15px/1.45 system-ui, sans-serif; margin: 0; background: var(--bg); color: #1b1b1b; }
  header { background: var(--c); color: #fff; padding: 12px 20px; display: flex; gap: 20px; align-items: center; flex-wrap: wrap; }
  header a { color: #fff; text-decoration: none; opacity: .85; }
  header a.on { opacity: 1; font-weight: 600; border-bottom: 2px solid #fff; }
  header .sp { flex: 1; }
  main { max-width: 1150px; margin: 20px auto; padding: 0 16px; }
  .card { background: #fff; border-radius: 10px; padding: 16px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,.08); }
  table { width: 100%; border-collapse: collapse; }
  th, td { text-align: left; padding: 8px 6px; border-bottom: 1px solid #e5e5e5; vertical-align: top; }
  th { font-size: 13px; color: #555; }
  code { font-size: 12.5px; word-break: break-all; }
  input[type=text], input[type=password], select { padding: 6px 8px; border: 1px solid #bbb; border-radius: 6px; font: inherit; }
  input.w { width: 100%; }
  button { padding: 6px 12px; border: 0; border-radius: 6px; background: var(--c); color: #fff; font: inherit; cursor: pointer; }
  button.red { background: var(--red); }
  button.grey { background: #777; }
  .msg { background: #e3f4e9; padding: 10px 14px; border-radius: 8px; margin-bottom: 14px; }
  .err { background: #fbe4e2; padding: 10px 14px; border-radius: 8px; margin-bottom: 14px; }
  .pill { display: inline-block; padding: 1px 8px; border-radius: 99px; font-size: 12px; color: #fff; }
  .high { background: var(--red); } .medium { background: #c77700; }
  .off { opacity: .45; }
  .grid { display: grid; grid-template-columns: 2fr 1.3fr 1fr 1.3fr 2.5fr auto; gap: 8px; align-items: center; }
  @media (max-width: 800px) { .grid { grid-template-columns: 1fr; } }
  form.inline { display: inline; }
  .login { max-width: 360px; margin: 80px auto; }
  .login input { width: 100%; margin-bottom: 10px; }
</style>
</head>
<body>
<?php if ($noAdmins || !$me): ?>
  <div class="card login">
    <h2><?= $noAdmins ? 'Első admin létrehozása' : 'Adware Scanner – admin' ?></h2>
    <?php if ($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
      <input type="hidden" name="action" value="<?= $noAdmins ? 'setup' : 'login' ?>">
      <input type="text" name="username" placeholder="Felhasználónév" required autofocus>
      <input type="password" name="password" placeholder="Jelszó<?= $noAdmins ? ' (min. 10 karakter)' : '' ?>" required>
      <button><?= $noAdmins ? 'Létrehozás' : 'Belépés' ?></button>
    </form>
  </div>
<?php else: ?>
<header>
  <strong>Adware Scanner</strong>
  <a href="?tab=suggestions" class="<?= $tab === 'suggestions' ? 'on' : '' ?>">Javaslatok</a>
  <a href="?tab=list" class="<?= $tab === 'list' ? 'on' : '' ?>">Tiltólista</a>
  <a href="?tab=account" class="<?= $tab === 'account' ? 'on' : '' ?>">Fiókok, eszközök</a>
  <span class="sp"></span>
  <span><?= h($me) ?></span>
  <a href="?logout=1">Kilépés</a>
</header>
<main>
  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?>

<?php if ($tab === 'suggestions'):
    $rows = $pdo->query("SELECT package,
            MAX(app_name) AS app_name, MAX(installer) AS installer,
            COUNT(*) AS cnt, MIN(created_at) AS first_at, MAX(created_at) AS last_at
        FROM suggestions WHERE status = 'pending'
        GROUP BY package ORDER BY cnt DESC, last_at DESC")->fetchAll();
    $notes = $pdo->prepare("SELECT note FROM suggestions WHERE package = ? AND status = 'pending' AND note <> '' ORDER BY created_at DESC LIMIT 5");
?>
  <div class="card">
    <h2>Függő javaslatok (<?= count($rows) ?>)</h2>
    <p>Az ügyfelek által „gyanús”-nak jelölt appok, csomagnév szerint összesítve. Jóváhagyáskor felkerülnek a nyilvános tiltólistára.</p>
    <?php if (!$rows): ?><p><em>Nincs függő javaslat.</em></p><?php endif; ?>
    <?php foreach ($rows as $r):
        $notes->execute([$r['package']]);
        $ns = $notes->fetchAll(PDO::FETCH_COLUMN); ?>
      <div style="border-top:1px solid #eee;padding:12px 0">
        <div>
          <strong><?= h($r['app_name'] ?: '(név nélkül)') ?></strong>
          · <code><?= h($r['package']) ?></code>
          · <?= (int)$r['cnt'] ?> bejelentés
          · forrás: <?= h($r['installer'] ?: 'ismeretlen') ?>
          · utolsó: <?= h($r['last_at']) ?> UTC
          · <a href="https://play.google.com/store/apps/details?id=<?= urlencode($r['package']) ?>" target="_blank" rel="noopener">Play Áruház</a>
          · <a href="https://www.google.com/search?q=<?= urlencode('"' . $r['package'] . '"') ?>" target="_blank" rel="noopener">Google</a>
        </div>
        <?php foreach ($ns as $n): ?><div style="color:#555;font-size:13px">„<?= h($n) ?>”</div><?php endforeach; ?>
        <form method="post" class="grid" style="margin-top:8px">
          <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
          <input type="hidden" name="action" value="save_entry">
          <input type="hidden" name="package" value="<?= h($r['package']) ?>">
          <input type="text" name="name" value="<?= h($r['app_name']) ?>" placeholder="App neve">
          <?= risk_select('medium') ?>
          <span></span>
          <?= cat_select('other') ?>
          <input type="text" name="reason" placeholder="Indoklás (ezt látja az ügyfél)" class="w">
          <button>Jóváhagy</button>
        </form>
        <form method="post" class="inline">
          <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
          <input type="hidden" name="action" value="reject">
          <input type="hidden" name="package" value="<?= h($r['package']) ?>">
          <button class="grey" style="margin-top:6px">Elutasít (nem kártevő)</button>
        </form>
      </div>
    <?php endforeach; ?>
  </div>

<?php elseif ($tab === 'list'):
    $q = clean_text($_GET['q'] ?? '', 100);
    if ($q !== '') {
        $st = $pdo->prepare('SELECT * FROM blacklist WHERE package LIKE ? OR name LIKE ? ORDER BY active DESC, risk, package');
        $st->execute(['%' . $q . '%', '%' . $q . '%']);
    } else {
        $st = $pdo->query('SELECT * FROM blacklist ORDER BY active DESC, risk, package');
    }
    $rows = $st->fetchAll();
    $edit = null;
    if (isset($_GET['edit'])) {
        $e = $pdo->prepare('SELECT * FROM blacklist WHERE id = ?');
        $e->execute([(int)$_GET['edit']]);
        $edit = $e->fetch() ?: null;
    }
?>
  <div class="card">
    <h2><?= $edit ? 'Bejegyzés szerkesztése' : 'Új app felvétele' ?></h2>
    <form method="post" class="grid">
      <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
      <input type="hidden" name="action" value="save_entry">
      <input type="text" name="package" placeholder="csomagnév, pl. com.pelda.app" required value="<?= h($edit['package'] ?? '') ?>" <?= $edit ? 'readonly' : '' ?>>
      <input type="text" name="name" placeholder="App neve" value="<?= h($edit['name'] ?? '') ?>">
      <?= risk_select($edit['risk'] ?? 'high') ?>
      <?= cat_select($edit['category'] ?? 'other') ?>
      <input type="text" name="reason" placeholder="Indoklás (ezt látja az ügyfél)" class="w" value="<?= h($edit['reason'] ?? '') ?>">
      <button>Mentés</button>
    </form>
    <?php if ($edit): ?><p><a href="?tab=list">Mégse</a></p><?php endif; ?>
  </div>
  <div class="card">
    <form method="get" style="margin-bottom:10px">
      <input type="hidden" name="tab" value="list">
      <input type="text" name="q" value="<?= h($q) ?>" placeholder="Keresés">
      <button>Keres</button>
      <span style="margin-left:12px;color:#555">Lista verzió: <?= list_version() ?> · nyilvános: <a href="../api/list.php" target="_blank">api/list.php</a></span>
    </form>
    <table>
      <tr><th>App</th><th>Kockázat</th><th>Kategória</th><th>Indoklás</th><th>Módosítva</th><th></th></tr>
      <?php foreach ($rows as $r): ?>
        <tr class="<?= $r['active'] ? '' : 'off' ?>">
          <td><strong><?= h($r['name']) ?></strong><br><code><?= h($r['package']) ?></code></td>
          <td><span class="pill <?= h($r['risk']) ?>"><?= h(RISKS[$r['risk']] ?? $r['risk']) ?></span></td>
          <td><?= h(CATEGORIES[$r['category']] ?? $r['category']) ?></td>
          <td><?= h($r['reason']) ?></td>
          <td style="font-size:13px"><?= h($r['updated_at']) ?><br><?= h($r['updated_by']) ?></td>
          <td style="white-space:nowrap">
            <a href="?tab=list&edit=<?= (int)$r['id'] ?>">Szerk.</a>
            <form method="post" class="inline">
              <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
              <input type="hidden" name="action" value="toggle_entry">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="grey"><?= $r['active'] ? 'Kikapcs.' : 'Bekapcs.' ?></button>
            </form>
            <form method="post" class="inline" onsubmit="return confirm('Végleg törlöd?')">
              <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
              <input type="hidden" name="action" value="delete_entry">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="red">Töröl</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>
  </div>

<?php else:
    $tokens = $pdo->query('SELECT t.id, t.label, t.created_at, t.expires_at, a.username FROM admin_tokens t JOIN admins a ON a.id = t.admin_id ORDER BY t.created_at DESC')->fetchAll();
    $admins = $pdo->query('SELECT username, created_at FROM admins ORDER BY username')->fetchAll();
?>
  <div class="card">
    <h2>Mobil szervizmenü bejelentkezések</h2>
    <p>Ezekről a telefonokról léptél be a rejtett szervizmenübe. Ha egy telefon elveszik vagy az ügyfélnél maradt bejelentkezve, itt vond vissza.</p>
    <table>
      <tr><th>Eszköz</th><th>Felhasználó</th><th>Létrehozva</th><th>Lejár</th><th></th></tr>
      <?php foreach ($tokens as $t): ?>
        <tr>
          <td><?= h($t['label']) ?></td><td><?= h($t['username']) ?></td>
          <td><?= h($t['created_at']) ?></td><td><?= h($t['expires_at']) ?></td>
          <td>
            <form method="post" class="inline">
              <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
              <input type="hidden" name="action" value="revoke_token">
              <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
              <button class="red">Visszavon</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>
  </div>
  <div class="card">
    <h2>Adminok</h2>
    <ul><?php foreach ($admins as $a): ?><li><?= h($a['username']) ?> (<?= h($a['created_at']) ?>)</li><?php endforeach; ?></ul>
    <form method="post" style="margin-bottom:10px">
      <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
      <input type="hidden" name="action" value="add_admin">
      <input type="text" name="username" placeholder="Új felhasználó" required>
      <input type="password" name="password" placeholder="Jelszó (min. 10)" required>
      <button>Hozzáadás</button>
    </form>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
      <input type="hidden" name="action" value="change_password">
      <input type="password" name="password" placeholder="Saját új jelszó (min. 10)" required>
      <button>Jelszócsere</button>
    </form>
  </div>
<?php endif; ?>
</main>
<?php endif; ?>
</body>
</html>
