-- Adware Scanner – SQLite séma (automatikusan lefut az első híváskor)

CREATE TABLE IF NOT EXISTS blacklist (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  package     VARCHAR(200) NOT NULL UNIQUE,
  name        VARCHAR(120) NOT NULL DEFAULT '',
  risk        VARCHAR(10)  NOT NULL DEFAULT 'medium',  -- high | medium
  category    VARCHAR(30)  NOT NULL DEFAULT 'other',
  reason      VARCHAR(300) NOT NULL DEFAULT '',
  active      TINYINT(1)   NOT NULL DEFAULT 1,
  created_at  DATETIME     NOT NULL,
  updated_at  DATETIME     NOT NULL,
  updated_by  VARCHAR(60)  NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS suggestions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  package     VARCHAR(200) NOT NULL,
  app_name    VARCHAR(120) NOT NULL DEFAULT '',
  installer   VARCHAR(120) NOT NULL DEFAULT '',
  note        VARCHAR(500) NOT NULL DEFAULT '',
  app_version VARCHAR(40)  NOT NULL DEFAULT '',
  ip_hash     CHAR(64)     NOT NULL DEFAULT '',
  status      VARCHAR(10)  NOT NULL DEFAULT 'pending', -- pending | approved | rejected
  created_at  DATETIME     NOT NULL
);

CREATE TABLE IF NOT EXISTS admins (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      VARCHAR(60)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    DATETIME     NOT NULL
);

CREATE TABLE IF NOT EXISTS admin_tokens (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id    INTEGER NOT NULL,
  token_hash  CHAR(64)     NOT NULL UNIQUE,
  label       VARCHAR(120) NOT NULL DEFAULT '',
  created_at  DATETIME     NOT NULL,
  expires_at  DATETIME     NOT NULL
);

CREATE TABLE IF NOT EXISTS login_attempts (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  ip_hash     CHAR(64)     NOT NULL,
  created_at  DATETIME     NOT NULL
);

CREATE TABLE IF NOT EXISTS meta (
  k VARCHAR(40)  NOT NULL PRIMARY KEY,
  v VARCHAR(200) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sugg_pkg ON suggestions (package);
CREATE INDEX IF NOT EXISTS idx_sugg_status ON suggestions (status);
CREATE INDEX IF NOT EXISTS idx_sugg_ip ON suggestions (ip_hash, created_at);
CREATE INDEX IF NOT EXISTS idx_tok_admin ON admin_tokens (admin_id);
CREATE INDEX IF NOT EXISTS idx_la ON login_attempts (ip_hash, created_at);
