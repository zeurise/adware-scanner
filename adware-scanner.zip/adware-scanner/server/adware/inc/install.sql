-- Adware Scanner – MySQL séma
-- Futtatás: mysql -u adware -p adware < install.sql   (utána: seed.sql)

CREATE TABLE IF NOT EXISTS blacklist (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  package     VARCHAR(200) NOT NULL UNIQUE,
  name        VARCHAR(120) NOT NULL DEFAULT '',
  risk        VARCHAR(10)  NOT NULL DEFAULT 'medium',  -- high | medium
  category    VARCHAR(30)  NOT NULL DEFAULT 'other',
  reason      VARCHAR(300) NOT NULL DEFAULT '',
  active      TINYINT(1)   NOT NULL DEFAULT 1,
  created_at  DATETIME     NOT NULL,
  updated_at  DATETIME     NOT NULL,
  updated_by  VARCHAR(60)  NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS suggestions (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  package     VARCHAR(200) NOT NULL,
  app_name    VARCHAR(120) NOT NULL DEFAULT '',
  installer   VARCHAR(120) NOT NULL DEFAULT '',
  note        VARCHAR(500) NOT NULL DEFAULT '',
  app_version VARCHAR(40)  NOT NULL DEFAULT '',
  ip_hash     CHAR(64)     NOT NULL DEFAULT '',
  status      VARCHAR(10)  NOT NULL DEFAULT 'pending', -- pending | approved | rejected
  created_at  DATETIME     NOT NULL,
  INDEX idx_sugg_pkg (package),
  INDEX idx_sugg_status (status),
  INDEX idx_sugg_ip (ip_hash, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admins (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(60)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    DATETIME     NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admin_tokens (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  admin_id    INT UNSIGNED NOT NULL,
  token_hash  CHAR(64)     NOT NULL UNIQUE,
  label       VARCHAR(120) NOT NULL DEFAULT '',
  created_at  DATETIME     NOT NULL,
  expires_at  DATETIME     NOT NULL,
  INDEX idx_tok_admin (admin_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ip_hash     CHAR(64)     NOT NULL,
  created_at  DATETIME     NOT NULL,
  INDEX idx_la (ip_hash, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS meta (
  k VARCHAR(40)  NOT NULL PRIMARY KEY,
  v VARCHAR(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
