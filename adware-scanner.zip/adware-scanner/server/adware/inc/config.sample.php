<?php
/**
 * Adware Scanner – szerver konfiguráció
 * Másold le config.php néven, és töltsd ki.
 */
return [
    // Adatbázis – alapértelmezés: SQLite (egyetlen fájl, nem kell adatbázis-szerver).
    // Az első híváskor magától létrejön a séma és a kezdő tiltólista.
    // A data/ mappa legyen írható a webszerver számára.
    'db_dsn'  => 'sqlite:' . __DIR__ . '/../data/adware.sqlite',
    'db_user' => '',
    'db_pass' => '',

    // MySQL helyette (ekkor kézzel futtasd: install.sql, majd seed.sql):
    // 'db_dsn'  => 'mysql:host=localhost;dbname=adware;charset=utf8mb4',
    // 'db_user' => 'adware',
    // 'db_pass' => 'IDE_JON_A_JELSZO',

    // Ügyféljavaslatok korlátja IP-címenként, naponta
    'suggest_limit_per_day' => 30,

    // Mobil admin token érvényessége (nap)
    'token_days' => 180,

    // Nyilvános linkek (tájékoztató oldal, nyomtatható lap)
    'public_url' => 'https://telefonvilag.hu/adware/',
    'github_url' => 'https://github.com/FELHASZNALO/adware-scanner',
    'apk_url'    => 'https://github.com/FELHASZNALO/adware-scanner/releases/latest',

    // Titkos só az IP-címek hasheléséhez (IP-t nem tárolunk nyersen)
    'ip_salt' => 'IDE_EGY_HOSSZU_VELETLEN_SZOVEG',
];
