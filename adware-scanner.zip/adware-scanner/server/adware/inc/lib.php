<?php
declare(strict_types=1);

const RISKS = ['high' => 'Magas', 'medium' => 'Közepes'];
const CATEGORIES = [
    'fake_updater' => 'Kamu frissítő',
    'fake_cleaner' => 'Kamu tisztító / vírusirtó',
    'recovery'     => 'Üzenet/fotó visszaállító',
    'sms_email'    => 'SMS / e-mail kliens',
    'camera'       => 'Beauty / HD kamera',
    'pdf_qr'       => 'PDF / QR olvasó klón',
    'gallery'      => 'Galéria / széf',
    'health_fake'  => 'Kamu egészségügyi mérő',
    'tool'         => 'Reklámos segédprogram',
    'game'         => 'Reklámos játék',
    'tracker'      => 'Helykövető / megfigyelő',
    'other'        => 'Egyéb',
];

function cfg(string $key)
{
    static $cfg = null;
    if ($cfg === null) {
        $file = __DIR__ . '/config.php';
        if (!is_file($file)) {
            http_response_code(500);
            exit('Hiányzik az inc/config.php (lásd config.sample.php)');
        }
        $cfg = require $file;
    }
    return $cfg[$key] ?? null;
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = (string)cfg('db_dsn');
        $isSqlite = str_starts_with($dsn, 'sqlite:');
        $fresh = $isSqlite && !is_file(substr($dsn, 7));
        $pdo = new PDO($dsn, (string)cfg('db_user'), (string)cfg('db_pass'), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        if ($isSqlite) {
            $pdo->exec('PRAGMA busy_timeout = 5000');
            $pdo->exec('PRAGMA journal_mode = WAL');
            if ($fresh) {
                // Első indítás: séma + kezdő tiltólista
                $pdo->exec((string)file_get_contents(__DIR__ . '/install_sqlite.sql'));
                $pdo->exec((string)file_get_contents(__DIR__ . '/seed.sql'));
            }
        }
    }
    return $pdo;
}

function now(): string
{
    return gmdate('Y-m-d H:i:s');
}

function json_out($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function json_in(): array
{
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $_POST;
}

/** Android csomagnév ellenőrzése: pl. com.example.app */
function valid_package(string $p): bool
{
    return strlen($p) <= 200 && (bool)preg_match('/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$/', $p);
}

function clean_text(?string $s, int $max): string
{
    $s = trim((string)$s);
    $s = preg_replace('/[\x00-\x1F\x7F]/u', ' ', $s) ?? '';
    return mb_substr($s, 0, $max);
}

function ip_hash(): string
{
    return hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . cfg('ip_salt'));
}

/** A lista verziója: a legutolsó módosítás ideje unix időben. */
function list_version(): int
{
    $v = db()->query("SELECT v FROM meta WHERE k = 'list_version'")->fetchColumn();
    return (int)$v;
}

function bump_list_version(): void
{
    $pdo = db();
    $v = time();
    $upd = $pdo->prepare("UPDATE meta SET v = ? WHERE k = 'list_version'");
    $upd->execute([(string)$v]);
    if ($upd->rowCount() === 0) {
        $pdo->prepare("INSERT INTO meta (k, v) VALUES ('list_version', ?)")->execute([(string)$v]);
    }
}

/** Bejegyzés felvétele vagy frissítése a feketelistán. */
function upsert_entry(string $pkg, string $name, string $risk, string $cat, string $reason, string $by): void
{
    $pdo = db();
    $exists = $pdo->prepare('SELECT id FROM blacklist WHERE package = ?');
    $exists->execute([$pkg]);
    $id = $exists->fetchColumn();
    if ($id) {
        $pdo->prepare('UPDATE blacklist SET name = ?, risk = ?, category = ?, reason = ?, active = 1, updated_at = ?, updated_by = ? WHERE id = ?')
            ->execute([$name, $risk, $cat, $reason, now(), $by, $id]);
    } else {
        $pdo->prepare('INSERT INTO blacklist (package, name, risk, category, reason, active, created_at, updated_at, updated_by) VALUES (?,?,?,?,?,1,?,?,?)')
            ->execute([$pkg, $name, $risk, $cat, $reason, now(), now(), $by]);
    }
    // ha volt rá függő javaslat, azt elfogadottnak jelöljük
    $pdo->prepare("UPDATE suggestions SET status = 'approved' WHERE package = ? AND status = 'pending'")->execute([$pkg]);
    bump_list_version();
}

/** Bearer token alapú admin azonosítás (mobil szervizmenü). */
function require_admin_token(): array
{
    // Egyes Apache/PHP-FPM beállítások elnyelik az Authorization fejlécet,
    // ezért az app az X-Admin-Token fejlécben is elküldi.
    $hdr = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($hdr === '' && !empty($_SERVER['HTTP_X_ADMIN_TOKEN'])) {
        $hdr = 'Bearer ' . $_SERVER['HTTP_X_ADMIN_TOKEN'];
    }
    if (!preg_match('/^Bearer\s+([A-Za-z0-9]{20,})$/', $hdr, $m)) {
        json_out(['ok' => false, 'error' => 'Bejelentkezés szükséges'], 401);
    }
    $st = db()->prepare('SELECT a.id, a.username FROM admin_tokens t JOIN admins a ON a.id = t.admin_id WHERE t.token_hash = ? AND t.expires_at > ?');
    $st->execute([hash('sha256', $m[1]), now()]);
    $admin = $st->fetch();
    if (!$admin) {
        json_out(['ok' => false, 'error' => 'Lejárt vagy érvénytelen bejelentkezés'], 401);
    }
    return $admin;
}

function h(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}
