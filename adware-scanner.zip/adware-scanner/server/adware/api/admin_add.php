<?php
/**
 * App közvetlen felvétele a tiltólistára a szervizmenüből.
 * POST /adware/api/admin_add.php   Authorization: Bearer <token>
 * JSON: { package, name, risk, category, reason }
 * GET ugyanitt: csak a token érvényességét ellenőrzi.
 */
declare(strict_types=1);
require __DIR__ . '/../inc/lib.php';

$admin = require_admin_token();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    json_out(['ok' => true, 'username' => $admin['username']]);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['ok' => false, 'error' => 'Csak POST'], 405);
}

$in = json_in();
$pkg = clean_text($in['package'] ?? '', 200);
if (!valid_package($pkg)) {
    json_out(['ok' => false, 'error' => 'Érvénytelen csomagnév'], 422);
}
$risk = isset(RISKS[$in['risk'] ?? '']) ? $in['risk'] : 'medium';
$cat = isset(CATEGORIES[$in['category'] ?? '']) ? $in['category'] : 'other';
$name = clean_text($in['name'] ?? '', 120);
$reason = clean_text($in['reason'] ?? '', 300);

upsert_entry($pkg, $name, $risk, $cat, $reason, $admin['username']);

json_out(['ok' => true, 'message' => 'Felvéve a tiltólistára.', 'version' => list_version()]);
