<?php
/**
 * Szervizmenü bejelentkezés.  POST /adware/api/admin_login.php
 * JSON: { username, password, label }  →  { ok, token, expires }
 */
declare(strict_types=1);
require __DIR__ . '/../inc/lib.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['ok' => false, 'error' => 'Csak POST'], 405);
}

$pdo = db();
$ip = ip_hash();
$since = gmdate('Y-m-d H:i:s', time() - 900);
$st = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip_hash = ? AND created_at > ?');
$st->execute([$ip, $since]);
if ((int)$st->fetchColumn() >= 10) {
    json_out(['ok' => false, 'error' => 'Túl sok sikertelen próbálkozás, várj 15 percet.'], 429);
}

$in = json_in();
$user = clean_text($in['username'] ?? '', 60);
$pass = (string)($in['password'] ?? '');

$st = $pdo->prepare('SELECT id, password_hash FROM admins WHERE username = ?');
$st->execute([$user]);
$admin = $st->fetch();

if (!$admin || !password_verify($pass, $admin['password_hash'])) {
    $pdo->prepare('INSERT INTO login_attempts (ip_hash, created_at) VALUES (?, ?)')->execute([$ip, now()]);
    json_out(['ok' => false, 'error' => 'Hibás felhasználónév vagy jelszó'], 401);
}

$token = bin2hex(random_bytes(24));
$expires = gmdate('Y-m-d H:i:s', time() + 86400 * (int)cfg('token_days'));
$pdo->prepare('INSERT INTO admin_tokens (admin_id, token_hash, label, created_at, expires_at) VALUES (?,?,?,?,?)')
    ->execute([$admin['id'], hash('sha256', $token), clean_text($in['label'] ?? 'Android', 120), now(), $expires]);

json_out(['ok' => true, 'token' => $token, 'username' => $user, 'expires' => $expires . 'Z']);
