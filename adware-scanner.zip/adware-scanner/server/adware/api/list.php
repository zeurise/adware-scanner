<?php
/**
 * Nyilvános feketelista.  GET /adware/api/list.php
 * ETag-et ad, így az app csak változáskor tölti le újra a teljes listát.
 */
declare(strict_types=1);
require __DIR__ . '/../inc/lib.php';

$version = list_version();
$etag = '"v' . $version . '"';
header('ETag: ' . $etag);
header('Cache-Control: public, max-age=300');

if (trim($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) {
    http_response_code(304);
    exit;
}

$rows = db()->query('SELECT package, name, risk, category, reason, updated_at FROM blacklist WHERE active = 1 ORDER BY package')->fetchAll();
$apps = [];
foreach ($rows as $r) {
    $apps[] = [
        'package'  => $r['package'],
        'name'     => $r['name'],
        'risk'     => $r['risk'],
        'category' => $r['category'],
        'reason'   => $r['reason'],
    ];
}

json_out([
    'ok'         => true,
    'version'    => $version,
    'updated'    => gmdate('c', $version),
    'count'      => count($apps),
    'categories' => CATEGORIES,
    'apps'       => $apps,
]);
