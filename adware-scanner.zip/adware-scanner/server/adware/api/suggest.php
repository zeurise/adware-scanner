<?php
/**
 * Ügyféljavaslat beküldése.  POST /adware/api/suggest.php
 * JSON: { package, app_name, installer, note, app_version }
 * Személyes adatot nem fogad: az IP-cím csak sózott hash-ként, a visszaélés-szűréshez kerül tárolásra.
 */
declare(strict_types=1);
require __DIR__ . '/../inc/lib.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['ok' => false, 'error' => 'Csak POST'], 405);
}

$in = json_in();
$pkg = clean_text($in['package'] ?? '', 200);
if (!valid_package($pkg)) {
    json_out(['ok' => false, 'error' => 'Érvénytelen csomagnév'], 422);
}

$pdo = db();

// Már tiltólistás? Akkor nem kell javaslat.
$st = $pdo->prepare('SELECT 1 FROM blacklist WHERE package = ? AND active = 1');
$st->execute([$pkg]);
if ($st->fetchColumn()) {
    json_out(['ok' => true, 'already_listed' => true, 'message' => 'Ez az alkalmazás már szerepel a tiltólistán.']);
}

// Időnként takarítás: 2 évnél régebbi javaslatok, 1 napnál régebbi belépési kísérletek
if (random_int(1, 50) === 1) {
    $pdo->prepare('DELETE FROM suggestions WHERE created_at < ?')->execute([gmdate('Y-m-d H:i:s', time() - 2 * 365 * 86400)]);
    $pdo->prepare('DELETE FROM login_attempts WHERE created_at < ?')->execute([gmdate('Y-m-d H:i:s', time() - 86400)]);
}

$ip = ip_hash();
$since = gmdate('Y-m-d H:i:s', time() - 86400);

$st = $pdo->prepare('SELECT COUNT(*) FROM suggestions WHERE ip_hash = ? AND created_at > ?');
$st->execute([$ip, $since]);
if ((int)$st->fetchColumn() >= (int)cfg('suggest_limit_per_day')) {
    json_out(['ok' => false, 'error' => 'Túl sok bejelentés ma, próbáld holnap.'], 429);
}

// Ugyanarról a címről ugyanazt az appot csak egyszer rögzítjük, amíg függőben van.
$st = $pdo->prepare("SELECT 1 FROM suggestions WHERE ip_hash = ? AND package = ? AND status = 'pending'");
$st->execute([$ip, $pkg]);
if (!$st->fetchColumn()) {
    $pdo->prepare('INSERT INTO suggestions (package, app_name, installer, note, app_version, ip_hash, status, created_at) VALUES (?,?,?,?,?,?,?,?)')
        ->execute([
            $pkg,
            clean_text($in['app_name'] ?? '', 120),
            clean_text($in['installer'] ?? '', 120),
            clean_text($in['note'] ?? '', 500),
            clean_text($in['app_version'] ?? '', 40),
            $ip,
            'pending',
            now(),
        ]);
}

json_out(['ok' => true, 'message' => 'Köszönjük! A bejelentést a szerviz átnézi.']);
