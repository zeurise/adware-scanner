Ide kerül az adware.sqlite adatbázisfájl. A mappa legyen írható a webszerver számára.
