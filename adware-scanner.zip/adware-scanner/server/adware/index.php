<?php
/**
 * Nyilvános tájékoztató oldal: https://telefonvilag.hu/adware/
 * Mit csinál az app, milyen adatot kezel, és a teljes aktuális tiltólista.
 */
declare(strict_types=1);
require __DIR__ . '/inc/lib.php';

$rows = db()->query('SELECT package, name, risk, category, reason FROM blacklist WHERE active = 1 ORDER BY risk, category, name')->fetchAll();
$version = list_version();
?>
<!doctype html>
<html lang="hu">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Adware Scanner – hogyan működik?</title>
<meta name="description" content="Az Adware Scanner ingyenes Android-alkalmazás, amely felismeri és eltávolíthatóvá teszi a reklámokkal teli, kéretlen alkalmazásokat.">
<style>
  body { font: 16px/1.6 system-ui, sans-serif; margin: 0; color: #1b1b1b; background: #f5f6f7; }
  .hero { background: #0b6b3a; color: #fff; padding: 36px 20px; text-align: center; }
  .hero h1 { margin: 0 0 6px; font-size: 30px; }
  main { max-width: 900px; margin: 0 auto; padding: 20px; }
  section { background: #fff; border-radius: 12px; padding: 18px 22px; margin-bottom: 18px; box-shadow: 0 1px 3px rgba(0,0,0,.07); }
  h2 { margin-top: 0; color: #0b6b3a; }
  .btn { display: inline-block; background: #0b6b3a; color: #fff; padding: 10px 18px; border-radius: 8px; text-decoration: none; margin: 4px 6px 4px 0; }
  .btn.alt { background: #333; }
  table { width: 100%; border-collapse: collapse; font-size: 14px; }
  th, td { text-align: left; padding: 7px 5px; border-bottom: 1px solid #eee; vertical-align: top; }
  code { font-size: 12.5px; word-break: break-all; color: #444; }
  .pill { display: inline-block; padding: 1px 8px; border-radius: 99px; font-size: 12px; color: #fff; white-space: nowrap; }
  .high { background: #b3261e; } .medium { background: #c77700; }
  footer { text-align: center; color: #666; font-size: 14px; padding: 10px 20px 30px; }
</style>
</head>
<body>
<div class="hero">
  <h1>Adware Scanner</h1>
  <div>Ingyenes védelem a reklámokkal teli, kéretlen alkalmazások ellen</div>
</div>
<main>
  <section>
    <h2>Mit csinál az alkalmazás?</h2>
    <ul>
      <li>Összeveti a telefonon lévő alkalmazásokat egy nyilvános <strong>tiltólistával</strong> (lent megtekinthető).</li>
      <li>Ha tiltott alkalmazást talál, megmutatja, miért gyanús, és egy gombnyomással <strong>eltávolíthatod</strong>. Az eltávolítást mindig a telefon saját megerősítő ablaka kéri, magától semmit nem töröl.</li>
      <li>A háttérben negyedóránként megnézi, települt-e új alkalmazás, és ha az tiltólistás, <strong>értesítést küld</strong>.</li>
      <li>Naponta egyszer letölti a friss tiltólistát.</li>
      <li>Bármelyik alkalmazást <strong>bejelentheted gyanúsként</strong>. A szerviz átnézi, és ha valóban kártevő, felkerül a listára – így mindenki védettebb lesz.</li>
    </ul>
    <a class="btn" href="<?= h((string)cfg('apk_url')) ?>">Letöltés (APK)</a>
    <a class="btn alt" href="<?= h((string)cfg('github_url')) ?>">Forráskód a GitHubon</a>
    <a class="btn alt" href="tajekoztato.php">Nyomtatható tájékoztató</a>
  </section>

  <section>
    <h2>Milyen adatot kezel?</h2>
    <p>Az alkalmazás <strong>nem gyűjt személyes adatot</strong>, nincs benne reklám és nincs fiók. A telefonon lévő alkalmazások listája a telefonon marad, az ellenőrzés helyben történik.</p>
    <p>A szerverre csak két esetben megy adat:</p>
    <ul>
      <li><strong>Lista letöltése:</strong> a telefon lekéri a tiltólistát (mint egy weboldal megnyitásakor).</li>
      <li><strong>Gyanús app bejelentése</strong> (csak ha te kezdeményezed): az alkalmazás csomagneve és neve, a telepítés forrása (pl. Play Áruház), az Adware Scanner verziója, és az általad írt megjegyzés. Az IP-címet nem tároljuk, csak egy visszafejthetetlen kódot belőle, a visszaélések kiszűrésére.</li>
    </ul>
    <p>Adatkezelő: TELEFONVILÁG Kereskedelmi és Szolgáltató Kft., kapcsolat@telefonvilag.hu</p>
  </section>

  <section>
    <h2>Az aktuális tiltólista (<?= count($rows) ?> alkalmazás)</h2>
    <p style="color:#666;font-size:14px">Utolsó módosítás: <?= h(date('Y.m.d. H:i', $version)) ?> · gépi formátumban: <a href="api/list.php">api/list.php</a></p>
    <table>
      <tr><th>Alkalmazás</th><th>Kockázat</th><th>Miért?</th></tr>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><strong><?= h($r['name']) ?></strong><br><code><?= h($r['package']) ?></code></td>
        <td><span class="pill <?= h($r['risk']) ?>"><?= h(RISKS[$r['risk']] ?? $r['risk']) ?></span></td>
        <td><?= h(CATEGORIES[$r['category']] ?? '') ?><br><span style="color:#555"><?= h($r['reason']) ?></span></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </section>
</main>
<footer>
  <strong>TELEFONVILÁG Kereskedelmi és Szolgáltató Kft.</strong> · 4033 Debrecen, Jázmin utca 8.<br>
  +36 70 772 2607 · <a href="mailto:kapcsolat@telefonvilag.hu">kapcsolat@telefonvilag.hu</a> · <a href="https://telefonvilag.hu">telefonvilag.hu</a><br>
  Fejlesztő: Csákó Attila · <a href="https://csakoattila.hu">csakoattila.hu</a>
</footer>
</body>
</html>
