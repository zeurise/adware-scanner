plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "hu.telefonvilag.adwarescanner"
    compileSdk = 35

    defaultConfig {
        applicationId = "hu.telefonvilag.adwarescanner"
        minSdk = 26          // Android 8.0 – a PackageManager.getChangedPackages() miatt
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        // A szerver API címe (a telefonvilag.hu/adware/ modul)
        buildConfigField("String", "API_BASE", "\"https://telefonvilag.hu/adware/api/\"")
        buildConfigField("String", "PUBLIC_URL", "\"https://telefonvilag.hu/adware/\"")
        // Állítsd be a saját GitHub-repód címére:
        buildConfigField("String", "GITHUB_URL", "\"https://github.com/FELHASZNALO/adware-scanner\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.core)
    implementation(libs.androidx.work.runtime.ktx)
    debugImplementation(libs.androidx.ui.tooling)
}
