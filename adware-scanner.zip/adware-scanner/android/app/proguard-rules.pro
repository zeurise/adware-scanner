# WorkManager a Worker osztályt reflexióval példányosítja
-keep class * extends androidx.work.ListenableWorker { <init>(...); }
