package hu.telefonvilag.adwarescanner.data

import hu.telefonvilag.adwarescanner.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** A telefonvilag.hu/adware/api/ hívásai. */
object Api {

    data class Result(val ok: Boolean, val message: String, val json: JSONObject? = null)

    /** Ügyfél: gyanús app bejelentése. */
    suspend fun suggest(app: InstalledApp, note: String): Result =
        post(
            "suggest.php",
            JSONObject()
                .put("package", app.packageName)
                .put("app_name", app.label)
                .put("installer", app.installerLabel)
                .put("note", note)
                .put("app_version", BuildConfig.VERSION_NAME),
        )

    /** Szervizmenü: bejelentkezés, token igénylése. */
    suspend fun adminLogin(username: String, password: String, deviceLabel: String): Result =
        post(
            "admin_login.php",
            JSONObject().put("username", username).put("password", password).put("label", deviceLabel),
        )

    /** Szervizmenü: app közvetlen felvétele a tiltólistára. */
    suspend fun adminAdd(token: String, pkg: String, name: String, risk: String, category: String, reason: String): Result =
        post(
            "admin_add.php",
            JSONObject()
                .put("package", pkg).put("name", name).put("risk", risk)
                .put("category", category).put("reason", reason),
            token,
        )

    private suspend fun post(path: String, body: JSONObject, token: String? = null): Result =
        withContext(Dispatchers.IO) {
            val conn = URL(BuildConfig.API_BASE + path).openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 15_000
                conn.readTimeout = 20_000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.setRequestProperty("User-Agent", "AdwareScanner/" + BuildConfig.VERSION_NAME)
                if (token != null) {
                    conn.setRequestProperty("Authorization", "Bearer $token")
                    conn.setRequestProperty("X-Admin-Token", token)
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val json = runCatching { JSONObject(text) }.getOrNull()
                val ok = code in 200..299 && json?.optBoolean("ok") == true
                val msg = json?.optString(if (ok) "message" else "error").orEmpty()
                    .ifEmpty { if (ok) "Kész." else "Hiba (HTTP $code)" }
                Result(ok, msg, json)
            } catch (e: Exception) {
                Result(false, "Nincs kapcsolat a szerverrel.")
            } finally {
                conn.disconnect()
            }
        }
}
