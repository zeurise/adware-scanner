package hu.telefonvilag.adwarescanner

import android.app.Application
import hu.telefonvilag.adwarescanner.work.Notifier
import hu.telefonvilag.adwarescanner.work.ScanWorker

class AdwareScannerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
        ScanWorker.schedule(this)
    }
}
