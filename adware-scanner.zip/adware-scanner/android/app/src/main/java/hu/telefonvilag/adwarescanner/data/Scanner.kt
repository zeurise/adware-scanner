package hu.telefonvilag.adwarescanner.data

/** Egy találat: telepített app, ami szerepel a tiltólistán. */
data class Threat(val app: InstalledApp, val entry: BlacklistEntry)

object Scanner {
    /**
     * Összeveti a telepített appokat a tiltólistával.
     * Rendszerappokat nem jelez (azok gyáriak, a felhasználó nem is tudja eltávolítani őket).
     */
    fun findThreats(apps: List<InstalledApp>, list: Blacklist): List<Threat> =
        apps.asSequence()
            .filter { !it.isSystem }
            .mapNotNull { app -> list[app.packageName]?.let { Threat(app, it) } }
            .sortedWith(compareByDescending<Threat> { it.entry.isHighRisk }.thenBy { it.app.label.lowercase() })
            .toList()
}
