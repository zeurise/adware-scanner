package hu.telefonvilag.adwarescanner.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import hu.telefonvilag.adwarescanner.data.Threat

@Composable
fun StatusScreen(state: UiState, vm: MainViewModel, onBattery: () -> Unit, modifier: Modifier = Modifier) {
    if (state.loading) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { StatusHeader(state, vm) }

        if (!state.batteryOk) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4E0))) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Háttérfigyelés engedélyezése", fontWeight = FontWeight.Bold)
                        Text(
                            "Egyes telefonok (pl. Xiaomi, Huawei) leállítják a háttérben futó appokat. " +
                                "Engedélyezd, hogy az Adware Scanner figyelhesse az új telepítéseket.",
                            fontSize = 14.sp,
                        )
                        TextButton(onClick = onBattery) { Text("Engedélyezés") }
                    }
                }
            }
        }

        if (state.threats.isNotEmpty()) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Talált tiltott alkalmazások", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    if (state.threats.size > 1) {
                        Button(
                            onClick = { vm.uninstallAll() },
                            colors = ButtonDefaults.buttonColors(containerColor = Danger),
                        ) { Text("Mindet törlöm") }
                    }
                }
            }
            items(state.threats, key = { it.app.packageName }) { t ->
                ThreatCard(t, state, onUninstall = { vm.uninstall(t.app.packageName) }, onIgnore = { vm.ignore(t.app.packageName) })
            }
        }

        if (state.ignoredThreats.isNotEmpty()) {
            item {
                Text("Elnémított (megtartott) tiltott appok", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
            }
            items(state.ignoredThreats, key = { "ign_" + it.app.packageName }) { t ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(t.app.packageName, 32.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(t.app.label, Modifier.weight(1f))
                        TextButton(onClick = { vm.unignore(t.app.packageName) }) { Text("Figyelmeztess újra") }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusHeader(state: UiState, vm: MainViewModel) {
    val bad = state.threats.isNotEmpty()
    val color = if (bad) Danger else Brand
    Card(colors = CardDefaults.cardColors(containerColor = color), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                if (bad) Icons.Filled.Warning else Icons.Filled.CheckCircle,
                contentDescription = null, tint = Color.White, modifier = Modifier.size(64.dp),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (bad) "${state.threats.size} tiltott alkalmazás található" else "Rendben, nincs tiltott alkalmazás",
                color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "${state.apps.count { !it.isSystem }} felhasználói app ellenőrizve · tiltólista: ${state.list.entries.size} app",
                color = Color.White.copy(alpha = .9f), fontSize = 13.sp,
            )
            Text(
                "Utolsó ellenőrzés: ${formatTime(state.lastScan)} · lista frissítve: ${formatTime(state.lastSync)}",
                color = Color.White.copy(alpha = .9f), fontSize = 12.sp,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.refresh() },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                ) { Text("Ellenőrzés most") }
                OutlinedButton(
                    onClick = { vm.syncNow() },
                    enabled = !state.syncing,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                ) { Text(if (state.syncing) "Frissítés…" else "Lista frissítése") }
            }
        }
    }
}

@Composable
private fun ThreatCard(t: Threat, state: UiState, onUninstall: () -> Unit, onIgnore: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(t.app.packageName, 44.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.app.label, fontWeight = FontWeight.Bold)
                    Text(t.app.packageName, fontSize = 11.sp, color = Color.Gray)
                }
                RiskBadge(t.entry.isHighRisk)
            }
            Spacer(Modifier.height(8.dp))
            Text(state.list.categoryLabel(t.entry.category), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(t.entry.reason, fontSize = 14.sp)
            Text(
                "Forrás: ${t.app.installerLabel} · telepítve: ${formatTime(t.app.firstInstall)}",
                fontSize = 12.sp, color = Color.Gray,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onIgnore) { Text("Megtartom") }
                Button(onClick = onUninstall, colors = ButtonDefaults.buttonColors(containerColor = Danger)) { Text("Törlés") }
            }
        }
    }
}

@Composable
fun RiskBadge(high: Boolean) {
    Text(
        if (high) "MAGAS" else "KÖZEPES",
        color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier
            .background(if (high) Danger else Warn, CircleShape)
            .padding(horizontal = 8.dp, vertical = 2.dp),
    )
}
