package hu.telefonvilag.adwarescanner.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import hu.telefonvilag.adwarescanner.data.InstalledApp

@Composable
fun AppsScreen(state: UiState, vm: MainViewModel, modifier: Modifier = Modifier) {
    var query by rememberSaveable { mutableStateOf("") }
    var showSystem by rememberSaveable { mutableStateOf(false) }
    var onlyUnknownSource by rememberSaveable { mutableStateOf(false) }
    var expanded by rememberSaveable { mutableStateOf<String?>(null) }
    var suggestFor by remember { mutableStateOf<InstalledApp?>(null) }
    var adminAddFor by remember { mutableStateOf<InstalledApp?>(null) }

    val q = query.trim().lowercase()
    val shown = state.apps.filter { a ->
        (showSystem || !a.isSystem) &&
            (!onlyUnknownSource || a.installer != "com.android.vending") &&
            (q.isEmpty() || a.label.lowercase().contains(q) || a.packageName.lowercase().contains(q))
    }

    Column(modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            placeholder = { Text("Keresés név vagy csomagnév szerint") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = onlyUnknownSource, onClick = { onlyUnknownSource = !onlyUnknownSource }, label = { Text("Nem Play Áruházból") })
            FilterChip(selected = showSystem, onClick = { showSystem = !showSystem }, label = { Text("Rendszerappok is") })
        }
        if (state.adminUser != null) {
            Text(
                "Szervizmód: ${state.adminUser} – koppints egy appra a tiltólistára vételhez",
                color = Brand, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }
        Text("${shown.size} alkalmazás", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(horizontal = 16.dp))

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(shown, key = { it.packageName }) { app ->
                val entry = state.list[app.packageName]
                val isOpen = expanded == app.packageName
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { expanded = if (isOpen) null else app.packageName },
                    colors = CardDefaults.cardColors(
                        containerColor = if (entry != null && !app.isSystem) Color(0xFFFDECEA) else Color.White,
                    ),
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(app.packageName, 38.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(app.label, fontWeight = FontWeight.SemiBold)
                                Text(app.packageName, fontSize = 11.sp, color = Color.Gray)
                                Text(
                                    "${app.installerLabel} · ${formatTime(app.firstInstall)}" + if (app.isSystem) " · rendszerapp" else "",
                                    fontSize = 11.sp, color = Color.Gray,
                                )
                            }
                            if (entry != null) RiskBadge(entry.isHighRisk)
                        }
                        if (isOpen) {
                            if (entry != null) {
                                Text(entry.reason, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(top = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
                            ) {
                                if (state.adminUser != null) {
                                    TextButton(onClick = { adminAddFor = app }) { Text("Tiltólistára") }
                                }
                                if (entry == null && !app.isSystem) {
                                    val done = app.packageName in state.reported
                                    TextButton(onClick = { suggestFor = app }, enabled = !done) {
                                        Text(if (done) "Bejelentve" else "Gyanús, bejelentem")
                                    }
                                }
                                if (!app.isSystem) {
                                    OutlinedButton(onClick = { vm.uninstall(app.packageName) }) { Text("Törlés") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    suggestFor?.let { app ->
        SuggestDialog(
            app = app,
            busy = state.busy,
            onDismiss = { suggestFor = null },
            onSend = { note, del ->
                vm.suggest(app, note, del)
                suggestFor = null
            },
        )
    }
    adminAddFor?.let { app ->
        AdminAddDialog(
            app = app,
            categories = state.list.categories.ifEmpty { DEFAULT_CATEGORIES },
            existing = state.list[app.packageName],
            busy = state.busy,
            onDismiss = { adminAddFor = null },
            onSave = { name, risk, cat, reason ->
                vm.adminAdd(app, name, risk, cat, reason) { adminAddFor = null }
            },
        )
    }
}

val DEFAULT_CATEGORIES = linkedMapOf(
    "fake_updater" to "Kamu frissítő",
    "fake_cleaner" to "Kamu tisztító / vírusirtó",
    "recovery" to "Üzenet/fotó visszaállító",
    "sms_email" to "SMS / e-mail kliens",
    "camera" to "Beauty / HD kamera",
    "pdf_qr" to "PDF / QR olvasó klón",
    "gallery" to "Galéria / széf",
    "health_fake" to "Kamu egészségügyi mérő",
    "tool" to "Reklámos segédprogram",
    "game" to "Reklámos játék",
    "tracker" to "Helykövető / megfigyelő",
    "other" to "Egyéb",
)
