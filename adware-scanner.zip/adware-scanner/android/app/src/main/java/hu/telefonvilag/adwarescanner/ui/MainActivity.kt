package hu.telefonvilag.adwarescanner.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import hu.telefonvilag.adwarescanner.data.Prefs

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private val uninstallLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.onUninstallFinished() }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Android 13+: értesítési engedély kérése egyszer
        val prefs = Prefs(this)
        if (Build.VERSION.SDK_INT >= 33 && !prefs.notificationAsked) {
            prefs.notificationAsked = true
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            AppTheme {
                val state by vm.state.collectAsStateWithLifecycle()
                val uninstallPkg by vm.uninstallRequest.collectAsStateWithLifecycle()
                val snackbar = remember { SnackbarHostState() }
                var tab by rememberSaveable { mutableIntStateOf(0) }

                LaunchedEffect(uninstallPkg) {
                    // forgatás után ne nyíljon meg kétszer ugyanaz az ablak
                    uninstallPkg?.let { if (vm.launchedFor != it) { vm.launchedFor = it; launchUninstall(it) } }
                }
                LaunchedEffect(state.message) {
                    state.message?.let {
                        snackbar.showSnackbar(it)
                        vm.consumeMessage()
                    }
                }

                Scaffold(
                    snackbarHost = { SnackbarHost(snackbar) },
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = tab == 0, onClick = { tab = 0 },
                                icon = { Icon(Icons.Filled.Home, null) },
                                label = { Text("Állapot") },
                            )
                            NavigationBarItem(
                                selected = tab == 1, onClick = { tab = 1 },
                                icon = { Icon(Icons.AutoMirrored.Filled.List, null) },
                                label = { Text("Összes app") },
                            )
                            NavigationBarItem(
                                selected = tab == 2, onClick = { tab = 2 },
                                icon = { Icon(Icons.Filled.Info, null) },
                                label = { Text("Névjegy") },
                            )
                        }
                    },
                ) { pad ->
                    val m = Modifier.padding(pad)
                    when (tab) {
                        0 -> StatusScreen(state, vm, ::openBatterySettings, m)
                        1 -> AppsScreen(state, vm, m)
                        else -> AboutScreen(state, vm, ::openUrl, m)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // pl. értesítésből törölt app, vagy kézzel eltávolított app után
        vm.refresh()
    }

    private fun launchUninstall(pkg: String) {
        @Suppress("DEPRECATION")
        val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
            .putExtra(Intent.EXTRA_RETURN_RESULT, true)
        try {
            uninstallLauncher.launch(intent)
        } catch (e: Exception) {
            vm.onUninstallFinished()
        }
    }

    @SuppressLint("BatteryLife")
    private fun openBatterySettings() {
        val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        try {
            startActivity(i)
        } catch (e: Exception) {
            runCatching { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
    }

    private fun openUrl(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }
}
