package hu.telefonvilag.adwarescanner.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import hu.telefonvilag.adwarescanner.R
import hu.telefonvilag.adwarescanner.data.Threat
import hu.telefonvilag.adwarescanner.ui.MainActivity

object Notifier {
    const val CHANNEL_THREATS = "threats"
    private const val SUMMARY_ID = 1

    fun createChannels(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(
            CHANNEL_THREATS,
            context.getString(R.string.channel_threats),
            NotificationManager.IMPORTANCE_HIGH,
        ).apply { description = context.getString(R.string.channel_threats_desc) }
        nm.createNotificationChannel(ch)
    }

    private fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun openAppIntent(context: Context): PendingIntent =
        PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    /** Egy új, tiltólistás app értesítése „Törlés” gombbal. */
    fun notifyThreat(context: Context, t: Threat) {
        if (!canNotify(context)) return
        val id = t.app.packageName.hashCode()
        val uninstall = PendingIntent.getActivity(
            context, id,
            Intent(Intent.ACTION_DELETE, Uri.parse("package:" + t.app.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val risk = if (t.entry.isHighRisk) "Magas kockázat" else "Közepes kockázat"
        val n = NotificationCompat.Builder(context, CHANNEL_THREATS)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setColor(0xFFB3261E.toInt())
            .setContentTitle("Tiltott alkalmazás: ${t.app.label}")
            .setContentText("$risk – ${t.entry.reason}")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$risk\n${t.entry.reason}\n\nCsomag: ${t.app.packageName}"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openAppIntent(context))
            .addAction(0, "Törlés", uninstall)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    /** Napi összesítő, ha még mindig van tiltott app a telefonon. */
    fun notifySummary(context: Context, count: Int) {
        if (!canNotify(context) || count <= 0) return
        val n = NotificationCompat.Builder(context, CHANNEL_THREATS)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setColor(0xFFB3261E.toInt())
            .setContentTitle("$count tiltott alkalmazás van a telefonon")
            .setContentText("Koppints ide az áttekintéshez és az eltávolításhoz.")
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(SUMMARY_ID, n)
        } catch (_: SecurityException) {
        }
    }

    fun cancel(context: Context, packageName: String) {
        NotificationManagerCompat.from(context).cancel(packageName.hashCode())
    }
}
