package hu.telefonvilag.adwarescanner.work

import android.content.Context
import android.provider.Settings
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import hu.telefonvilag.adwarescanner.data.AppInventory
import hu.telefonvilag.adwarescanner.data.BlacklistRepository
import hu.telefonvilag.adwarescanner.data.Prefs
import hu.telefonvilag.adwarescanner.data.Scanner
import hu.telefonvilag.adwarescanner.data.Threat
import java.util.concurrent.TimeUnit

/**
 * Háttérellenőrzés, kb. 15 percenként.
 *  - Gyors út: csak az előző futás óta telepített/frissített csomagokat nézi meg.
 *  - Naponta egyszer: friss listát tölt le, és minden appot újraellenőriz.
 */
class ScanWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val prefs = Prefs(ctx)
        val repo = BlacklistRepository.get(ctx)
        val inventory = AppInventory(ctx)
        val now = System.currentTimeMillis()

        // 1) Napi listafrissítés (hálózati hiba esetén a meglévő listával megyünk tovább)
        var listChanged = false
        if (now - prefs.lastSync > SYNC_INTERVAL_MS) {
            listChanged = repo.sync() is BlacklistRepository.SyncResult.Updated
        }
        val list = repo.current()

        // 2) Teljes vagy gyors ellenőrzés?
        val bootCount = Settings.Global.getInt(ctx.contentResolver, Settings.Global.BOOT_COUNT, 0)
        val rebooted = bootCount != prefs.bootCount
        val fullScan = rebooted || listChanged || now - prefs.lastFullScan > FULL_SCAN_INTERVAL_MS

        val ignored = prefs.ignored
        val threats: List<Threat>
        if (fullScan) {
            threats = Scanner.findThreats(inventory.all(), list).filter { it.app.packageName !in ignored }
        } else {
            // csak a változott csomagok
            val changed = ctx.packageManager.getChangedPackages(prefs.changeSequence)
            if (changed != null) prefs.changeSequence = changed.sequenceNumber
            val apps = changed?.packageNames.orEmpty().mapNotNull { inventory.find(it) }
            threats = Scanner.findThreats(apps, list).filter { it.app.packageName !in ignored }
        }

        // 3) Értesítés az újonnan talált tiltott appokról
        val notified = prefs.notified.toMutableSet()
        val fresh = threats.filter { it.app.packageName !in notified }
        if (fresh.size > MAX_SINGLE_NOTIFICATIONS) {
            // pl. első futáskor egy teleszemetelt telefonon: egy összesítő, nem 30 külön értesítés
            Notifier.notifySummary(ctx, threats.size)
        } else {
            fresh.forEach { Notifier.notifyThreat(ctx, it) }
        }
        fresh.forEach { notified += it.app.packageName }

        if (fullScan) {
            // A már nem létező / már nem tiltott appokat kivesszük az értesítettek közül,
            // így ha újra feltelepítik, újra szólunk.
            val current = threats.map { it.app.packageName }.toSet()
            notified.retainAll(current)
            // Napi emlékeztető, ha korábban jelzett app még mindig fent van
            val stillThere = current.count { it in prefs.notified }
            if (stillThere > 0 && !rebooted && fresh.size <= MAX_SINGLE_NOTIFICATIONS) {
                Notifier.notifySummary(ctx, current.size)
            }

            prefs.lastFullScan = now
            prefs.bootCount = bootCount
            // újraindítás után a sorszám nulláról indul
            // (null = a rendszerindítás óta nem változott semmi → 0 a helyes sorszám)
            prefs.changeSequence = ctx.packageManager.getChangedPackages(0)?.sequenceNumber ?: 0
        }

        prefs.notified = notified
        prefs.lastScan = now
        return Result.success()
    }

    companion object {
        private const val WORK_NAME = "adware_scan"
        private const val MAX_SINGLE_NOTIFICATIONS = 3
        private val SYNC_INTERVAL_MS = TimeUnit.HOURS.toMillis(20)
        private val FULL_SCAN_INTERVAL_MS = TimeUnit.HOURS.toMillis(24)

        fun schedule(context: Context) {
            val req = PeriodicWorkRequestBuilder<ScanWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
