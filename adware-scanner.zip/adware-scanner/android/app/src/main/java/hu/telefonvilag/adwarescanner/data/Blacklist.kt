package hu.telefonvilag.adwarescanner.data

import org.json.JSONObject

/** Egy tiltólistás bejegyzés. */
data class BlacklistEntry(
    val packageName: String,
    val name: String,
    val risk: String,       // "high" | "medium"
    val category: String,
    val reason: String,
) {
    val isHighRisk: Boolean get() = risk == "high"
}

/** A teljes tiltólista, ahogy a szerver (vagy a beépített másolat) adja. */
data class Blacklist(
    val version: Long,
    val entries: Map<String, BlacklistEntry>,
    val categories: Map<String, String>,
) {
    operator fun get(packageName: String): BlacklistEntry? = entries[packageName]

    fun categoryLabel(key: String): String = categories[key] ?: key

    companion object {
        val EMPTY = Blacklist(0, emptyMap(), emptyMap())

        /** A szerver api/list.php válaszának feldolgozása. */
        fun parse(json: String): Blacklist {
            val root = JSONObject(json)
            val apps = root.getJSONArray("apps")
            val entries = HashMap<String, BlacklistEntry>(apps.length())
            for (i in 0 until apps.length()) {
                val o = apps.getJSONObject(i)
                val pkg = o.getString("package")
                entries[pkg] = BlacklistEntry(
                    packageName = pkg,
                    name = o.optString("name"),
                    risk = o.optString("risk", "medium"),
                    category = o.optString("category", "other"),
                    reason = o.optString("reason"),
                )
            }
            val cats = HashMap<String, String>()
            root.optJSONObject("categories")?.let { c ->
                c.keys().forEach { k -> cats[k] = c.getString(k) }
            }
            return Blacklist(root.optLong("version"), entries, cats)
        }
    }
}
